client_script "client.lua"

files {
  'index.html',
  'main.css',
  'logo.png',
  'music/music.ogg',
  'js/background-changer.86080.js',
  'images/1.jpg',
  'images/2.jpg',
  'images/3.jpg',
  'images/4.jpg',
}

loadscreen_manual_shutdown "yes"
loadscreen 'index.html'

fx_version 'adamant'
games { 'gta5' }
